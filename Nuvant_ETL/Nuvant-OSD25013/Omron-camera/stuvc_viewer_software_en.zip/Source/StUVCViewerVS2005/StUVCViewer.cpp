/*
	StUVCViewer by OMRON SENTECH Technical Support Division.

	WIN32 API-based GUI sample program.
	This program use CameraFunction.g/.cpp to access and control STC-S133UVC.

	Notice: 
	   This is a sample program for STC-S133UVC in Windows environment.
	   We do not guarantee that this program will work within all kinds of environment and with any other devices.

*/

#include "stdafx.h"
#include "StUVCViewer.h"
#include "CameraFunctions.h"

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;								// current instance
TCHAR szTitle[MAX_LOADSTRING];					// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];			// the main window class name

// Camera function class object for operation
CameraFunctions CMFObj;

// Forward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	FPS_Process(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	Video_Path_Process(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	BMP_Path_Process(HWND, UINT, WPARAM, LPARAM);

//
int APIENTRY _tWinMain( HINSTANCE hInstance,
                        HINSTANCE hPrevInstance,
                        LPTSTR    lpCmdLine,
                        int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	MSG msg;
	HACCEL hAccelTable;

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_STUVCVIEWER, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow))
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_STUVCVIEWER));

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0))
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return (int) msg.wParam;
}



//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_STUVCVIEWER));
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= MAKEINTRESOURCE(IDC_STUVCVIEWER);
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

	return RegisterClassEx(&wcex);
}

//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   HWND hWnd;

   hInst = hInstance; // Store instance handle in our global variable

   hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

   if (!hWnd)
   {
      return FALSE;
   }

   // Show up main window
   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

// Interface update function.
// Main Window menu items status update function.
void UpdateMenuItem(CameraFunctions * CamObj, HMENU hndMenu)
{
	if (CamObj == NULL || hndMenu == NULL)
		return;

	// isPreviewing flag
	if (CamObj->CMFstatFlagStorage.fIsPreviewing)
	{
		CheckMenuItem(hndMenu, IDM_CAPTURE_PREVIEW, MF_BYCOMMAND | MFS_CHECKED);
		EnableMenuItem(hndMenu, IDM_CAPTURE_CAPTUREVIDEO, MF_ENABLED);
		EnableMenuItem(hndMenu, IDM_CAPTURE_SNAP, MF_ENABLED);
	}
	else
	{
		CheckMenuItem(hndMenu, IDM_CAPTURE_PREVIEW, MF_BYCOMMAND | MFS_UNCHECKED);
		// If not in preview, also disable capture AVI & snap for that input pin should be paused and will get nothing.
		EnableMenuItem(hndMenu, IDM_CAPTURE_CAPTUREVIDEO, MF_DISABLED);
		EnableMenuItem(hndMenu, IDM_CAPTURE_SNAP, MF_DISABLED);
	}

	// isOnCapture shows if currently is making AVI.
	if (CamObj->CMFstatFlagStorage.fIsOnCapture)
	{
		CheckMenuItem(hndMenu, IDM_CAPTURE_CAPTUREVIDEO, MF_BYCOMMAND | MFS_CHECKED);
		EnableMenuItem(hndMenu, IDM_CAPTURE_SNAP, MF_DISABLED);
		EnableMenuItem(hndMenu, IDM_CAPTURE_PREVIEW, MF_DISABLED);
	}
	else
	{
		CheckMenuItem(hndMenu, IDM_CAPTURE_CAPTUREVIDEO, MF_BYCOMMAND | MFS_UNCHECKED);
		EnableMenuItem(hndMenu, IDM_CAPTURE_PREVIEW, MF_ENABLED);
		if(CamObj->CMFstatFlagStorage.fIsPreviewing)
		{
			EnableMenuItem(hndMenu, IDM_CAPTURE_SNAP, MF_ENABLED);
		}
		else
		{
			EnableMenuItem(hndMenu, IDM_CAPTURE_SNAP, MF_DISABLED);
		}
	}
}

//
// Main Window handling class
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;

	// Get handle of menu bar for later usage.
	HMENU hndMenu = GetMenu(hWnd);

	CMF_RTN initRst = 0x00;

	switch (message)
	{
	case WM_CREATE:
		// ==== Global Parameter initial
		CMFObj.CMFstatFlagStorage.fIsCaptureVideoOn = FALSE;
		CMFObj.CMFstatFlagStorage.fIsConnected = FALSE;
		CMFObj.CMFstatFlagStorage.fIsOnCapture = FALSE;
		CMFObj.CMFstatFlagStorage.fIsPreviewing = FALSE;
		CMFObj.CMFstatFlagStorage.fIsSnapOn = FALSE;

		// ==== Menu items initial
		EnableMenuItem(hndMenu, IDM_CAPTURE_CAPTUREVIDEO, MF_DISABLED);
		EnableMenuItem(hndMenu, IDM_CAPTURE_SNAP, MF_DISABLED);

		// ==== Camera related functions / Camera initial.
		if (CMFObj.CMF_connectToCamera() != TRUE)
		{
			MessageBox(hWnd, L"Cannot Connect to camera.\nPress OK to exit program.", L"Connect to Camera Failed!", MB_OK);
			CMFObj.CMF_DisconnectCamera();
			DestroyWindow(hWnd);
			PostQuitMessage(0);
			break;
		}
		CMFObj.CMFstatFlagStorage.fIsConnected = TRUE;
		// Set snap on as default.
		CMFObj.CMFstatFlagStorage.fIsSnapOn = TRUE;
		// === Initial DShow related components
		initRst = CMFObj.CMF_RenderGraphWithInnerDisplay(hWnd);
		if (!initRst == CMF_RENDER_OK_BUT_MPEG_ENCODER_NOT_AVAILABLE || !initRst == CMF_OK)
		{
			MessageBox(hWnd, L"DirectShow components initial failed.\nPress OK to exit program.", L"Render Graph Failed!", MB_OK);
			CMFObj.CMF_DisconnectCamera();
			DestroyWindow(hWnd);
			PostQuitMessage(0);
			break;
		}
		break;
	case WM_COMMAND:
		wmId    = LOWORD(wParam);
		wmEvent = HIWORD(wParam);
		// Parse the menu selections:
		switch (wmId)
		{
		case IDM_ABOUT:
			DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
			break;
		case IDM_CAPTURE_SET_FPS:
			// Open Set FPS dialog.
			DialogBox(hInst, MAKEINTRESOURCE(IDD_DIAG_FPS), hWnd, FPS_Process);
			break;
		case IDM_CAPTURE_SET_VIDEO_PATH:
			// Open Set AVI path/name dialog.
			DialogBox(hInst, MAKEINTRESOURCE(IDD_DIAG_VIDEO), hWnd, Video_Path_Process);
			break;
		case IDM_CAPTURE_SET_SNAP_PATH:
			// Open Set BMP path/name dialog.
			DialogBox(hInst, MAKEINTRESOURCE(IDD_DIAG_SNAP), hWnd, BMP_Path_Process);
			break;
		case IDM_EXIT:
			// Exit and terminate window.
			CMFObj.CMF_StopCapture();
			CMFObj.CMF_DisconnectCamera();
			DestroyWindow(hWnd);
			break;
		case IDM_SETTING_VIDEO_FILTER_SETTING:
		{
			if(CMFObj.CMFstatFlagStorage.fIsConnected != TRUE)
				break;

			// Call and show up camera (filter) setting window.
			CMFObj.CMF_openVideoFilterSetting(hWnd);
			break;
		}
		case IDM_SETTING_VIDEO_PIN_SETTING:
		{
			if(CMFObj.CMFstatFlagStorage.fIsConnected != TRUE)
				break;
			
			// Call and show up filter pin setting window.
			CMFObj.CMF_openVideoPinSetting(hWnd);
			break;
		}
		case IDM_CAPTURE_PREVIEW:
			// Switch on/off preview.
			CMFObj.CMFstatFlagStorage.fIsPreviewing = !CMFObj.CMFstatFlagStorage.fIsPreviewing;
			if (CMFObj.CMFstatFlagStorage.fIsPreviewing == TRUE)
			{
				if (CMFObj.CMF_StartCapture() != TRUE)
				{
					MessageBox(hWnd, L"Start capture failed.\nPress OK to exit program.", L"Start Capture Failed!", MB_OK);
					CMFObj.CMF_StopCapture();
					CMFObj.CMF_DisconnectCamera();
					PostQuitMessage(0);
					break;
				}
				// Set Snap on if Preview is on.
				CMFObj.CMFstatFlagStorage.fIsSnapOn = TRUE;
			}
			else
			{
				if (CMFObj.CMF_StopCapture() != TRUE)
				{
					MessageBox(hWnd, L"Stop capture failed.\nPress OK to exit program.", L"Start Capture Failed!", MB_OK);
					CMFObj.CMF_DisconnectCamera();
					PostQuitMessage(0);
					break;
				}
				// Set Snap off if Preivew is off
				CMFObj.CMFstatFlagStorage.fIsSnapOn = FALSE;
			}
			UpdateMenuItem(&CMFObj, hndMenu);
			break;
		case IDM_CAPTURE_CAPTUREVIDEO:
			// Start/Stop AVI capture.
			if (CMFObj.CMFstatFlagStorage.fIsOnCapture)		// Stop capture
			{
				// Set Flags
				CMFObj.CMFstatFlagStorage.fIsCaptureVideoOn = FALSE;
				CMFObj.CMFstatFlagStorage.fIsOnCapture = FALSE;
				CMFObj.CMFstatFlagStorage.fIsSnapOn = TRUE;
				// Re-render graph with caputreVideoOn flag off / Snap on.
				CMFObj.CMF_StopCapture();
				CMFObj.CMF_TeardownGraph();
				CMFObj.CMF_RenderGraphWithInnerDisplay(hWnd);
				if (CMFObj.CMFstatFlagStorage.fIsPreviewing)
					CMFObj.CMF_StartCapture();
			}
			else	// Start capture
			{
				// Set Flags
				CMFObj.CMFstatFlagStorage.fIsCaptureVideoOn = TRUE;
				CMFObj.CMFstatFlagStorage.fIsOnCapture = TRUE;
				CMFObj.CMFstatFlagStorage.fIsSnapOn = FALSE;
				// Re-render graph with captureVideoOn flag on / Snap off.
				CMFObj.CMF_StopCapture();
				CMFObj.CMF_TeardownGraph();
				
				CMF_RTN renderRst = CMFObj.CMF_RenderGraphWithInnerDisplay(hWnd);
				if (renderRst == CMF_RENDER_OK_BUT_MPEG_ENCODER_NOT_AVAILABLE)
				{
					// Rendering the encoder failed. Need to show up inform message.
					MessageBox(hWnd, L"MPEG Encoder Initial Failed.\nVideo will be saved as AVI format and the file size will be very large.", L"MPEG Encoder Not Initialed.", MB_OK);
				}
				CMFObj.CMF_StartCapture();
			}
			UpdateMenuItem(&CMFObj, hndMenu);
			break;
		case IDM_CAPTURE_SNAP:
			// Snap current image to BMP.
			if (CMFObj.CMFstatFlagStorage.fIsSnapOn != TRUE)
				break;

			wchar_t BMPfileName[FILENAME_MAX];
			_stprintf_s(BMPfileName, FILENAME_MAX, CMFObj.snapFileName, CMFObj.BMP_SaveCount);
			if (!CMFObj.CMF_Snap(BMPfileName))
			{
				MessageBox(hWnd, L"Snap failed.", L"Snap Failed!", MB_OK);
			}
			CMFObj.BMP_SaveCount++;

			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
		break;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		EndPaint(hWnd, &ps);
		break;
	case WM_DESTROY:
		CMFObj.CMF_StopCapture();
		CMFObj.CMF_DisconnectCamera();
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

// Message handler for FPS setting dialog.
INT_PTR CALLBACK FPS_Process(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	TCHAR  tach[32];
	HRESULT hr;
	float cntFPS = -1;
	int wmId, wmEvent;
	double dFrameRate;

	switch (message)
	{
	case WM_INITDIALOG:
		// Read current FPS and put into dialogBox
		cntFPS = CMFObj.CMF_GetOutputFPS();
		if (cntFPS < 0)
		{
			// Get FPS failed. Error handling.
			MessageBox(hDlg, L"Cannot Get FPS value.", L"Acquire Value Failed", MB_OK);
			EndDialog(hDlg, FALSE);
		}
		hr = StringCchPrintf(tach, 32, TEXT("%d\0"), (int)cntFPS);
		SetDlgItemText(hDlg, IDC_EDIT_FPS, tach);
		return (INT_PTR)TRUE;
	case WM_COMMAND:
		wmId = LOWORD(wParam);
		wmEvent = HIWORD(wParam);

		switch (wParam)
		{
		case IDC_FPS_OK:
			GetDlgItemText(hDlg, IDC_EDIT_FPS, tach, sizeof(tach) / sizeof(tach[0]));
			dFrameRate = _wtof(tach);

			if (dFrameRate <= 0)
			{
				// Invalid value, error handling.
				MessageBox(hDlg, L"Invalid FPS value.", L"Invalid Value.", MB_OK);
				break;
			}
			else
			{
				if (!CMFObj.CMF_SetOutputFPS((float)dFrameRate))
				{
					// Set FPS failed. Error handling.
					MessageBox(hDlg, L"Set FPS Failed. If preview is on, please turn it off and try again.", L"Set Failed", MB_OK);
					break;
				}
				// Check real framerate. Sometimes the tgt frame cannot be set and will automatically set to nearest value.
				cntFPS = CMFObj.CMF_GetOutputFPS();
				if ((double)cntFPS != dFrameRate)
				{
					wchar_t msg[100];
					_stprintf_s(msg, 100, _T("FPS Value Has Modified to %d Due to Camera Limitation."), (int)cntFPS);
					MessageBox(hDlg, msg, L"FPS Value Modified", MB_OK);
				}
			}
			EndDialog(hDlg, TRUE);
			break;
		case IDCANCEL:
			EndDialog(hDlg, TRUE);
			break;
		}
	}
	return (INT_PTR)FALSE;
}

// Message Handler for AVI path setting dialog
INT_PTR CALLBACK Video_Path_Process(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	int wmId, wmEvent;
	wchar_t input[FILENAME_MAX];

	switch (message)
	{
	case WM_INITDIALOG:
		SetDlgItemText(hDlg, IDC_VIDEO_PATH_EDIT, CMFObj.VideoFileName);
		break;
	case WM_COMMAND:
		wmId = LOWORD(wParam);
		wmEvent = HIWORD(wParam);

		switch (wParam)
		{
		case IDOK:
			GetDlgItemText(hDlg, IDC_VIDEO_PATH_EDIT, input, FILENAME_MAX);
			wcsncpy(CMFObj.VideoFileName, input, FILENAME_MAX);
			EndDialog(hDlg, TRUE);
			break;
		case IDCANCEL:
			EndDialog(hDlg, TRUE);
			break;
		}
	}
	return (INT_PTR)FALSE;
}

// Message handler for BMP path setting dialog
INT_PTR CALLBACK BMP_Path_Process(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	int wmId, wmEvent;
	wchar_t input[FILENAME_MAX];

	switch (message)
	{
	case WM_INITDIALOG:
		SetDlgItemText(hDlg, IDC_EDIT_SNAP_BMP_PATH, CMFObj.snapFileName);
		break;
	case WM_COMMAND:
		wmId = LOWORD(wParam);
		wmEvent = HIWORD(wParam);

		switch (wParam)
		{
		case IDOK:
			GetDlgItemText(hDlg, IDC_EDIT_SNAP_BMP_PATH, input, FILENAME_MAX);
			wcsncpy(CMFObj.snapFileName, input, FILENAME_MAX);
			// Reset counter here
			CMFObj.BMP_SaveCount = 0;
			EndDialog(hDlg, TRUE);
			break;
		case IDCANCEL:
			EndDialog(hDlg, TRUE);
			break;
		}
	}
	return (INT_PTR)FALSE;
}