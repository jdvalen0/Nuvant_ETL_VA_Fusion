//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by StUVCViewer.rc
//
#define IDC_MYICON                      2
#define IDD_STUVCVIEWER_DIALOG          102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_STUVCVIEWER                 107
#define IDI_SMALL                       108
#define IDC_STUVCVIEWER                 109
#define IDR_MAINFRAME                   128
#define IDD_DIAG_FPS                    129
#define IDD_DIAG_VIDEO                  130
#define IDD_DIAG_SNAP                   131
#define IDM_CAPTURE_PREVIEW             204
#define IDM_CAPTURE_CAPTUREVIDEO        205
#define IDM_CAPTURE_SNAP                206
#define IDM_CAPTURE_SET_FPS             207
#define IDM_CAPTURE_SET_VIDEO_PATH      208
#define IDM_CAPTURE_SET_SNAP_PATH       209
#define IDC_FPS_OK                      1000
#define IDC_EDIT_FPS                    1001
#define IDC_VIDEO_PATH_EDIT             1002
#define IDC_STATIC_VIDEO_SAVE           1003
#define IDC_EDIT1                       1004
#define IDC_EDIT_SNAP_BMP_PATH          1004
#define IDM_SETTING_VIDEO_PIN_SETTING   32780
#define IDM_SETTING_VIDEO_FILTER_SETTING 32781
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
