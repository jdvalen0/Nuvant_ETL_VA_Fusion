/*
	CameraFunctions.cpp by OMRON SENTECH Support Team
	
	This cpp file implements the camera related funtions with using DirectShow.


 */

#include "stdafx.h"
#include "CameraFunctions.h"

// Connect to UVC camera by using enumeration of DirectShow input devices.
BOOL CameraFunctions::CMF_connectToCamera()
{
	ICreateDevEnum *pCreateDevEnum = NULL;
	IEnumMoniker *pEnumMoniker = NULL;
	IMoniker *pMoniker = NULL;
	ULONG nFetched = 0;
	HRESULT hRst = false;

	// Initial COM components. Necessary for DShow using.
	CoInitialize(NULL);

	// Create DShow device enumeration components for listing devices
	CoCreateInstance(CLSID_SystemDeviceEnum, NULL, CLSCTX_INPROC_SERVER, IID_ICreateDevEnum, (PVOID *)&pCreateDevEnum);
	pCreateDevEnum->CreateClassEnumerator(CLSID_VideoInputDeviceCategory, &pEnumMoniker, 0);
	
	// If NULL -> No device detected.
	if (pEnumMoniker == NULL) {
		pCreateDevEnum->Release();
		return FALSE;
	}

	// Call Reset() to make sure it point back to the first device
	pEnumMoniker->Reset();

	// Get the FriendlyName of every device to check if target device is exist.
	while (pEnumMoniker->Next(1, &pMoniker, &nFetched) == S_OK) {
		IPropertyBag *pPropertyBag;
		char devname[256];

		hRst = pMoniker->BindToStorage(0, 0, IID_IPropertyBag, (void **)&pPropertyBag);
		if (hRst != S_OK)
			break;

		VARIANT var;
		var.vt = VT_BSTR;
		hRst = pPropertyBag->Read(L"FriendlyName", &var, 0);
		if (hRst != S_OK)
			break;

		WideCharToMultiByte(CP_ACP, 0, var.bstrVal, -1, devname, sizeof(devname), 0, 0);
		VariantClear(&var);

		if (strcmp(devname, DEV_NAME) == 0) {
			pMoniker->BindToObject(0, 0, IID_IBaseFilter, (void**)&pDeviceFilter);
		}
		pMoniker->Release();
		pPropertyBag->Release();

		if (pDeviceFilter != NULL) {
			break;
		}
	}

	// Release component after use
	pCreateDevEnum->Release();
	pEnumMoniker->Release();

	if (pDeviceFilter != NULL)
	{
		// If device found, Initial/reset counter and component.
		pMux = NULL;
		BMP_SaveCount = 0;

		// Set Default paths
		wchar_t tmpPath[MAX_PATH];
		memset(tmpPath, 0x0, MAX_PATH);
		wchar_t tmpSnapFileName[100] = L"\\UVCViewerSnap%d.BMP";
		HRESULT hRstGP = SHGetFolderPath(NULL, CSIDL_MYPICTURES, NULL, SHGFP_TYPE_CURRENT, tmpPath);
		if(hRstGP != S_OK)
		{
			// Get My Picture Path failed.
			return FALSE;
		}
		wcscat(snapFileName, tmpPath);
		wcscat(snapFileName, tmpSnapFileName);

		wchar_t tmpAVIFileName[100] = L"\\UVC_Capture.avi";
		wcscat(VideoFileName, tmpPath);
		wcscat(VideoFileName, tmpAVIFileName);
		wcscat(VideoBasePath, tmpPath);

		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

// Open and show the setting window of camera.
BOOL CameraFunctions::CMF_openVideoFilterSetting(HWND parentWndHnd)
{
	if(pDeviceFilter == NULL)
		return FALSE;

	ISpecifyPropertyPages *pSpec;
	CAUUID cauuid;

	HRESULT hr = pDeviceFilter->QueryInterface(IID_ISpecifyPropertyPages, (void **)&pSpec);
	if (SUCCEEDED(hr))
	{
		hr = pSpec->GetPages(&cauuid);
		if (SUCCEEDED(hr) && cauuid.cElems > 0)
		{
			hr = OleCreatePropertyFrame(parentWndHnd, 30, 30, NULL, 1, (IUnknown **)&pDeviceFilter, cauuid.cElems, (GUID *)cauuid.pElems, 0, 0, NULL);
			CoTaskMemFree(cauuid.pElems);
		}
		pSpec->Release();
		return TRUE;
	}
	return FALSE;
}

// Open and show the output pin setting window of camera
BOOL CameraFunctions::CMF_openVideoPinSetting(HWND parentWndHnd)
{
	if(pDeviceFilter == NULL)
		return FALSE;

	// Be aware that pin setting need to stop preview for correct working.
	if(CMFstatFlagStorage.fIsPreviewing)
	{
		if(!CMF_StopCapture())
			return FALSE;
	}
	// Also, current graph need to be tear down
	CMF_I_RemoveDownstream(pDeviceFilter);
	SafeRelease(pGraphBuilder);
	SafeRelease(pSampleGrabberFilter);
	SafeRelease(pSampleGrabber);
	SafeRelease(pMux);
	SafeRelease(pVideoWindow);

	IAMStreamConfig *pSC;
	ISpecifyPropertyPages *pSpec;
	CAUUID cauuid;

	HRESULT hr = pCaptureGraphBuilder2->FindInterface(&PIN_CATEGORY_CAPTURE, &MEDIATYPE_Video, pDeviceFilter, IID_IAMStreamConfig, (void **)&pSC);
	if (!SUCCEEDED(hr))
		return FALSE;

	hr = pSC->QueryInterface(IID_ISpecifyPropertyPages, (void **)&pSpec);
	if (SUCCEEDED(hr))
	{
		hr = pSpec->GetPages(&cauuid);
		if (SUCCEEDED(hr) && cauuid.cElems > 0)
		{
			hr = OleCreatePropertyFrame(parentWndHnd, 30, 30, NULL, 1, (IUnknown **)&pSC, cauuid.cElems, (GUID *)cauuid.pElems, 0, 0, NULL);
			CoTaskMemFree(cauuid.pElems);
		}
	}
	else
	{
		pSC->Release();
		return FALSE;
	}

	// Release related component after setting.
	pSC->Release();
	pSpec->Release();
	SafeRelease(pCaptureGraphBuilder2);

	// Re-Render the graph after setting.
	if(!CMF_RenderGraphWithInnerDisplay(parentWndHnd))
		return FALSE;

	// Set back to its original status after setting
	if(CMFstatFlagStorage.fIsPreviewing)
	{
		CMF_StartCapture();
	}

	return TRUE;
}

// Function for handling DShow related works for including and connecting all components then make it works.
// This function will create a DShow display window for display.
CMF_RTN CameraFunctions::CMF_RenderGraph()
{
	if(wcslen(VideoFileName) == 0)
	{
		return CMF_FILE_NAME_NOT_SET;
	}

	if (pDeviceFilter == NULL)
	{
		return CMF_RENDER_DEVICE_NOT_INITIALED;
	}

	HRESULT hRst;
	AM_MEDIA_TYPE am_media_type;
	bool isEncoderRendered = false;

	// For Snap is on, we need to prepear some more components.
	if (CMFstatFlagStorage.fIsSnapOn)
	{
		// Create sample grabber instance. This is for acquiring still image data from camera.
		CoCreateInstance(CLSID_SampleGrabber, NULL, CLSCTX_INPROC, IID_IBaseFilter, (LPVOID *)&pSampleGrabberFilter);
		// Initial related information of sample grabber.
		pSampleGrabberFilter->QueryInterface(IID_ISampleGrabber, (LPVOID *)&pSampleGrabber);
		AM_MEDIA_TYPE amt;
		ZeroMemory(&amt, sizeof(amt));
		amt.majortype = MEDIATYPE_Video;
		amt.subtype = MEDIASUBTYPE_RGB24;
		amt.formattype = FORMAT_VideoInfo;
		pSampleGrabber->SetMediaType(&amt);
	}

	// Create GraphBuilder instance.
	CoCreateInstance(CLSID_FilterGraph, NULL, CLSCTX_INPROC, IID_IGraphBuilder, (LPVOID *)&pGraphBuilder);
	// Create GraphBuilder2 instance. This is for automatically render the DShow graph.
	CoCreateInstance(CLSID_CaptureGraphBuilder2, NULL, CLSCTX_INPROC, IID_ICaptureGraphBuilder2, (LPVOID *)&pCaptureGraphBuilder2);
	// Set the relationship of GraphBuilder and GraphBuilder2.
	pCaptureGraphBuilder2->SetFiltergraph(pGraphBuilder);
	// Add device (filter) into GraphBuilder.
	pGraphBuilder->AddFilter(pDeviceFilter, L"Device Filter");

	ICreateDevEnum *pDevEnum = NULL;
	IEnumMoniker *pCompressorClassEnum = NULL;
	pDevEnum->CreateClassEnumerator(CLSID_MediaEncoderCategory, &pCompressorClassEnum, 0);
	pCompressorClassEnum->Reset();

	IMoniker *pCompressorMoniker = NULL;
	IBaseFilter *pCompressor = NULL;
	ULONG cFetched = 0;

	if (pCompressorClassEnum->Next(1, &pCompressorMoniker, &cFetched) == S_OK)
	{
		// Bind to the first filter object of the moniker.
		pCompressorMoniker->BindToObject(0, 0, IID_IBaseFilter, (void **)&pCompressor);
		pCompressorMoniker->Release();
	}

	pCompressorClassEnum->Release();

	pDevEnum->Release();

	pGraphBuilder->AddFilter(pCompressor, L"Compressor");


	// === Following sequences are divided by status of snap on / capture video on flags.
	//     By differnet setting, the detail will be different.

	// If only Snap set to on...
	if (CMFstatFlagStorage.fIsSnapOn && !CMFstatFlagStorage.fIsCaptureVideoOn)
	{
		hRst = pGraphBuilder->AddFilter(pSampleGrabberFilter, L"Sample Grabber");
		// Render Device filter and sample grabber filter for acquiring still image from capture pin.
		hRst = pCaptureGraphBuilder2->RenderStream(&PIN_CATEGORY_CAPTURE, NULL, pDeviceFilter, NULL, pSampleGrabberFilter);
		if (hRst != S_OK)
			return CMF_RENDER_SAMPLE_GRABBER_FAILED;
		// Render preview pin of Device filter with auto-assign for display image.
		// Notice that here hRst will not be S_OK due to our device does not have a preview pin and iCaptureGraphBuilder2 will automatically generate a smart tee for providing preview.
		hRst = pCaptureGraphBuilder2->RenderStream(&PIN_CATEGORY_PREVIEW, NULL, pDeviceFilter, NULL, NULL);
		
		// After rendering, get some more detail from SampleGrabber.
		hRst = pSampleGrabber->GetConnectedMediaType(&am_media_type);
		if (hRst != S_OK)
		{
			printf("GetConnectedMediaType failed.\n");
			return CMF_RENDER_GET_MEDIA_TYPE_FAILED;

		}
		// Set VideoinfoHeader for later using around BMP saving.
		pVideoInfoHeader = (VIDEOINFOHEADER *)am_media_type.pbFormat;
		// Set SampleGrabber to grab image information. Note this will slightly increase the loading but it's necessary to set to true to get still image.
		pSampleGrabber->SetBufferSamples(TRUE);
	}
	// If both set to on..
	else if (CMFstatFlagStorage.fIsCaptureVideoOn && CMFstatFlagStorage.fIsSnapOn)
	{
		// SampleGrabber is necessary for still image capturing.
		hRst = pGraphBuilder->AddFilter(pSampleGrabberFilter, L"Sample Grabber");

		// Check if AVI file path/name is set. If not we give it a default path/name otherwise we cannot initial AVI related components.
		// AVI file path/name is for CaptureGraphBuilder2 to set output pin.
		hRst = pCaptureGraphBuilder2->SetOutputFileName(&MEDIASUBTYPE_Avi, VideoFileName, &pMux, NULL);

		if (hRst != S_OK)
		{
			printf("Set File Name/Path Failed.\n");
			return FALSE;
		}

		// Render components (filters). Note that the parameter is different from above for that the components should be connected as following:
		//
		//		Device -> SampleGrabber -> Mux -> AVI File
		//
		// Which "Mux -> AVI File" has been set by SetOutputFileName() above. Note that Mux is nessary for AVI output.
		hRst = pCaptureGraphBuilder2->RenderStream(&PIN_CATEGORY_CAPTURE, NULL, pDeviceFilter, pSampleGrabberFilter, pMux);
		if (hRst != S_OK)
			return FALSE;

		// Render preview pin of Device filter with auto-assign for display image.
		// Notice that here hRst will not be S_OK due to our device does not have a preview pin and iCaptureGraphBuilder2 will automatically generate a smart tee for providing preview.
		hRst = pCaptureGraphBuilder2->RenderStream(&PIN_CATEGORY_PREVIEW, NULL, pDeviceFilter, NULL, NULL);

		// After rendering, get some more detail from SampleGrabber.
		hRst = pSampleGrabber->GetConnectedMediaType(&am_media_type);
		if (hRst != S_OK)
		{
			printf("GetConnectedMediaType failed.\n");
		}
		pVideoInfoHeader = (VIDEOINFOHEADER *)am_media_type.pbFormat;
		pSampleGrabber->SetBufferSamples(TRUE);

		// After all set, use CMF_PauseAviCapture() to temporary disable output of Device Filter to prevent immediate Video creation.
		if (!CMFstatFlagStorage.fIsOnCapture)
		{
			CMF_PauseAviCapture();
		}
	}
	// If only capture Video is set...
	else if (!CMFstatFlagStorage.fIsSnapOn && CMFstatFlagStorage.fIsCaptureVideoOn)
	{
		IBaseFilter *pMsMpegEncoder = NULL;

		if(CMF_I_FindMpegEncoderFilter(&pMsMpegEncoder))
		{
			// Encoder Filter found. Otherwise the pMsMpegEncoder will be set to NULL.
			pGraphBuilder->AddFilter(pMsMpegEncoder, L"Encoder");
		}

		// Check if Video file path/name is set. If not we give it a default path/name otherwise we cannot initial Video related components.
		// Video file path/name is for CaptureGraphBuilder2 to set output pin.
		// After that, render components (filters). For that we need not to capture still image, it should be connected as following:
		//
		//		Device -> Mux -> Mpeg encoder(If possible, use it) -> Video File
		//

		// If no encoder found
		if(pMsMpegEncoder == NULL)
		{
			hRst = pCaptureGraphBuilder2->SetOutputFileName(&MEDIASUBTYPE_Avi, VideoFileName, &pMux, NULL);
			// Try render graph
			hRst = pCaptureGraphBuilder2->RenderStream(&PIN_CATEGORY_CAPTURE, &MEDIATYPE_Video, pDeviceFilter, NULL, pMux);
			if(hRst != S_OK)
			{
				return CMF_RENDER_NO_ENCODER_RENDER_FAILED;
			}
		}
		// Encoder found, trying to render with encoder.
		else
		{
			// Change output file type from avi to mpeg.
			size_t iLeng = wcslen(VideoFileName);
			VideoFileName[iLeng - 3] = 'm';
			VideoFileName[iLeng - 2] = 'p';
			VideoFileName[iLeng - 1] = 'g';

			IFileSinkFilter * pSinkFilter = NULL;
			hRst = pCaptureGraphBuilder2->SetOutputFileName(&CLSID_FileWriter, VideoFileName, &pMux, &pSinkFilter);
			// Render graph
			hRst = pCaptureGraphBuilder2->RenderStream(&PIN_CATEGORY_CAPTURE, &MEDIATYPE_Video, pDeviceFilter, pMsMpegEncoder, pMux);
			
			if (hRst != S_OK)
			{
				return CMF_RENDER_ENCODER_FOUND_BUT_RENDER_FAILED;
			}
			isEncoderRendered = true;
		}

		// Render preview pin of Device filter with auto-assign for display image.
		// Notice that here hRst will not be S_OK due to our device does not have a preview pin and iCaptureGraphBuilder2 will automatically generate a smart tee for providing preview.
		hRst = pCaptureGraphBuilder2->RenderStream(&PIN_CATEGORY_PREVIEW, NULL, pDeviceFilter, NULL, NULL);
		if (!CMFstatFlagStorage.fIsOnCapture)
		{
			CMF_PauseAviCapture();
		}
	}
	// For both of capture does not set, render only preview pin for preview.
	else
	{
		pCaptureGraphBuilder2->RenderStream(&PIN_CATEGORY_PREVIEW, NULL, pDeviceFilter, NULL, NULL);
	}
	pGraphBuilder->QueryInterface(IID_IVideoWindow, (LPVOID *)&pVideoWindow);
	pVideoWindow->put_Caption(L"STC-S133UVC");
	// Show up display window
	pVideoWindow->put_Visible(OATRUE);

	if(!isEncoderRendered)
		return CMF_RENDER_OK_BUT_MPEG_ENCODER_NOT_AVAILABLE;
	else
		return CMF_OK;
}

// Function for handling DShow related works for including and connecting all components then make it works.
// This function will try to prepear to display image inside the parent window (parentWnd).
CMF_RTN CameraFunctions::CMF_RenderGraphWithInnerDisplay(HWND parentWnd)
{
	if(wcslen(VideoFileName) == 0)
	{
		return CMF_FILE_NAME_NOT_SET;
	}

	if (pDeviceFilter == NULL)
	{
		return CMF_RENDER_DEVICE_NOT_INITIALED;
	}

	HRESULT hRst;
	AM_MEDIA_TYPE am_media_type;
	bool isEncoderRendered = false;

	if (CMFstatFlagStorage.fIsSnapOn)
	{
		// For Snap is on, we need to prepear some more components.
		CoCreateInstance(CLSID_SampleGrabber, NULL, CLSCTX_INPROC, IID_IBaseFilter, (LPVOID *)&pSampleGrabberFilter);
		pSampleGrabberFilter->QueryInterface(IID_ISampleGrabber, (LPVOID *)&pSampleGrabber);
		// Initial related information of sample grabber.
		AM_MEDIA_TYPE amt;
		ZeroMemory(&amt, sizeof(amt));
		amt.majortype = MEDIATYPE_Video;
		amt.subtype = MEDIASUBTYPE_RGB24;
		amt.formattype = FORMAT_VideoInfo;
		pSampleGrabber->SetMediaType(&amt);
	}

	// Create GraphBuilder instance.
	CoCreateInstance(CLSID_FilterGraph, NULL, CLSCTX_INPROC, IID_IGraphBuilder, (LPVOID *)&pGraphBuilder);
	// Create GraphBuilder2 instance. This is for automatically render the DShow graph.
	CoCreateInstance(CLSID_CaptureGraphBuilder2, NULL, CLSCTX_INPROC, IID_ICaptureGraphBuilder2, (LPVOID *)&pCaptureGraphBuilder2);
	// Set the relationship of GraphBuilder and GraphBuilder2.
	pCaptureGraphBuilder2->SetFiltergraph(pGraphBuilder);
	// Add device (filter) into GraphBuilder.
	pGraphBuilder->AddFilter(pDeviceFilter, L"Device Filter");

	// === Following sequences are divided by status of snap on / capture video on flags.
	//     By differnet setting, the detail will be different.

	// If only Snap set to on...
	if (CMFstatFlagStorage.fIsSnapOn && !CMFstatFlagStorage.fIsCaptureVideoOn)
	{
		hRst = pGraphBuilder->AddFilter(pSampleGrabberFilter, L"Sample Grabber");
		// Render Device filter and sample grabber filter for acquiring still image from capture pin.
		hRst = pCaptureGraphBuilder2->RenderStream(&PIN_CATEGORY_CAPTURE, NULL, pDeviceFilter, NULL, pSampleGrabberFilter);
		if (hRst != S_OK)
			return CMF_RENDER_SAMPLE_GRABBER_FAILED;
		// Render preview pin of Device filter with auto-assign for display image.
		// Notice that here hRst will not be S_OK due to our device does not have a preview pin and iCaptureGraphBuilder2 will automatically generate a smart tee for providing preview.
		hRst = pCaptureGraphBuilder2->RenderStream(&PIN_CATEGORY_PREVIEW, NULL, pDeviceFilter, NULL, NULL);
		
		// After rendering, get some more detail from SampleGrabber.
		hRst = pSampleGrabber->GetConnectedMediaType(&am_media_type);
		if (hRst != S_OK)
		{
			printf("GetConnectedMediaType failed.\n");
			return CMF_RENDER_GET_MEDIA_TYPE_FAILED;

		}
		// Set VideoinfoHeader for later using around BMP saving.
		pVideoInfoHeader = (VIDEOINFOHEADER *)am_media_type.pbFormat;
		// Set SampleGrabber to grab image information. Note this will slightly increase the loading but it's necessary to set to true to get still image.
		pSampleGrabber->SetBufferSamples(TRUE);
	}
	// If both set to on..
	else if (CMFstatFlagStorage.fIsCaptureVideoOn && CMFstatFlagStorage.fIsSnapOn)
	{
		// SampleGrabber is necessary for still image capturing.
		hRst = pGraphBuilder->AddFilter(pSampleGrabberFilter, L"Sample Grabber");

		// Check if AVI file path/name is set. If not we give it a default path/name otherwise we cannot initial AVI related components.
		// AVI file path/name is for CaptureGraphBuilder2 to set output pin.
		hRst = pCaptureGraphBuilder2->SetOutputFileName(&MEDIASUBTYPE_Avi, VideoFileName, &pMux, NULL);

		if (hRst != S_OK)
		{
			printf("Set File Name/Path Failed.\n");
			return CMF_FILE_NAME_NOT_SET;
		}

		// Render components (filters). Note that the parameter is different from above for that the components should be connected as following:
		//
		//		Device -> SampleGrabber -> Mux -> AVI File
		//
		// Which "Mux -> AVI File" has been set by SetOutputFileName() above. Note that Mux is nessary for AVI output.
		hRst = pCaptureGraphBuilder2->RenderStream(&PIN_CATEGORY_CAPTURE, NULL, pDeviceFilter, pSampleGrabberFilter, pMux);
		if (hRst != S_OK)
			return CMF_RENDER_SAMPLE_GRABBER_FAILED;

		// Render preview pin of Device filter with auto-assign for display image.
		// Notice that here hRst will not be S_OK due to our device does not have a preview pin and iCaptureGraphBuilder2 will automatically generate a smart tee for providing preview.
		hRst = pCaptureGraphBuilder2->RenderStream(&PIN_CATEGORY_PREVIEW, NULL, pDeviceFilter, NULL, NULL);

		// After rendering, get some more detail from SampleGrabber.
		hRst = pSampleGrabber->GetConnectedMediaType(&am_media_type);
		if (hRst != S_OK)
		{
			printf("GetConnectedMediaType failed.\n");
		}
		pVideoInfoHeader = (VIDEOINFOHEADER *)am_media_type.pbFormat;
		pSampleGrabber->SetBufferSamples(TRUE);

		// After all set, use CMF_PauseAviCapture() to temporary disable output of Device Filter to prevent immediate AVI creation.
		if (!CMFstatFlagStorage.fIsOnCapture)
		{
			CMF_PauseAviCapture();
		}
	}
	// If only capture Video is set...
	else if (!CMFstatFlagStorage.fIsSnapOn && CMFstatFlagStorage.fIsCaptureVideoOn)
	{
		// Try to find MPEG encoder
		if(CMF_I_FindMpegEncoderFilter(&pMsMpegEncoder))
		{
			// Encoder Filter found. Otherwise the pMsMpegEncoder will be set to NULL.
			pGraphBuilder->AddFilter(pMsMpegEncoder, L"Encoder");
		}

		// Check if AVI file path/name is set. If not we give it a default path/name otherwise we cannot initial AVI related components.
		// AVI file path/name is for CaptureGraphBuilder2 to set output pin.
		// After that, render components (filters). For that we need not to capture still image, it should be connected as following:
		//
		//		Device -> Mux -> Mpeg encoder(If possible, use it) -> AVI File
		//

		// If no encoder found
		if(pMsMpegEncoder == NULL)
		{
			hRst = pCaptureGraphBuilder2->SetOutputFileName(&MEDIASUBTYPE_Avi, VideoFileName, &pMux, NULL);
			// Try render graph
			hRst = pCaptureGraphBuilder2->RenderStream(&PIN_CATEGORY_CAPTURE, &MEDIATYPE_Video, pDeviceFilter, NULL, pMux);
			if(hRst != S_OK)
			{
				return CMF_RENDER_NO_ENCODER_RENDER_FAILED;
			}
		}
		// Encoder found, trying to render with encoder.
		else
		{
			// Change output file type from avi to mpeg.
			size_t iLeng = wcslen(VideoFileName);
			VideoFileName[iLeng - 3] = 'm';
			VideoFileName[iLeng - 2] = 'p';
			VideoFileName[iLeng - 1] = 'g';

			IFileSinkFilter * pSinkFilter = NULL;
			hRst = pCaptureGraphBuilder2->SetOutputFileName(&CLSID_FileWriter, VideoFileName, &pMux, &pSinkFilter);
			// Render graph
			hRst = pCaptureGraphBuilder2->RenderStream(&PIN_CATEGORY_CAPTURE, &MEDIATYPE_Video, pDeviceFilter, pMsMpegEncoder, pMux);
			
			if (hRst != S_OK)
			{
				return CMF_RENDER_ENCODER_FOUND_BUT_RENDER_FAILED;
			}
			isEncoderRendered = true;
		}

		// Render preview pin of Device filter with auto-assign for display image.
		// Notice that here hRst will not be S_OK due to our device does not have a preview pin and iCaptureGraphBuilder2 will automatically generate a smart tee for providing preview.
		hRst = pCaptureGraphBuilder2->RenderStream(&PIN_CATEGORY_PREVIEW, NULL, pDeviceFilter, NULL, NULL);
		if (!CMFstatFlagStorage.fIsOnCapture)
		{
			CMF_PauseAviCapture();
		}
	}
	// For both of capture does not set, render only preview pin for preview.
	else
	{
		pCaptureGraphBuilder2->RenderStream(&PIN_CATEGORY_PREVIEW, NULL, pDeviceFilter, NULL, NULL);
	}

	// For displaying inside the parent window, we need to set parent window properly to correctly display the image.
	// Acquire device output height / width.
	IAMStreamConfig *pVSC;
	VIDEOINFOHEADER * pVideoInfoHeaderForProp;
	hRst = pCaptureGraphBuilder2->FindInterface(&PIN_CATEGORY_CAPTURE, &MEDIATYPE_Video, pDeviceFilter, IID_IAMStreamConfig, (void **)&pVSC);
	if (hRst != S_OK)
		return CMF_RENDER_CANNOT_FOUND_INNER_DISPLAY_WINDOW;

	AM_MEDIA_TYPE *pmt;
	hRst = pVSC->GetFormat(&pmt);
	if (hRst != S_OK)
		return CMF_RENDER_CANNOT_ACQUIRE_MEDIA_FORMAT;

	pVideoInfoHeaderForProp = (VIDEOINFOHEADER *)pmt->pbFormat;
	pGraphBuilder->QueryInterface(IID_IVideoWindow, (LPVOID *)&pVideoWindow);

	// Initial inner display window related components
	pVideoWindow->put_Owner((OAHWND)parentWnd);
	pVideoWindow->put_WindowStyle(WS_CHILD | WS_CLIPSIBLINGS);
	RECT cRect;
	cRect.top = 0;
	cRect.left = 0;
	cRect.right = pVideoInfoHeaderForProp->bmiHeader.biWidth;
	cRect.bottom = pVideoInfoHeaderForProp->bmiHeader.biHeight;
	// Get actural needed size of main window by setting the size of client window.
	AdjustWindowRect(&cRect, WS_OVERLAPPEDWINDOW, TRUE);
	// Set main window size and position.
	SetWindowPos(parentWnd, HWND_TOP, 0, 0, cRect.right - cRect.left, cRect.bottom - cRect.top, SWP_NOMOVE);
	// Set inner display window size.
	pVideoWindow->SetWindowPosition(0, 0, cRect.right, cRect.bottom);
	pVideoWindow->SetWindowForeground(OATRUE);
	// Show up display window
	pVideoWindow->put_Visible(OATRUE);

	SafeRelease(pVSC);
	CoTaskMemFree(pVideoInfoHeaderForProp);

	if(!isEncoderRendered)
		return CMF_RENDER_OK_BUT_MPEG_ENCODER_NOT_AVAILABLE;
	else
		return CMF_OK;
}

// (For DShow display window) Set the position of display window.
void CameraFunctions::CMF_SetDisplayVideoWndPos(long lX, long lY)
{
	if (pVideoWindow == NULL)
		return;

	pVideoWindow->put_Left(lX);
	pVideoWindow->put_Top(lY);
	return;
}

// Snap for current image.
BOOL CameraFunctions::CMF_Snap(wchar_t * fileName)
{
	if (pSampleGrabber == NULL)
	{
		// Sample grabber not initialed
		return FALSE;
	}

	HRESULT rst;
	long nBufferSize = 0;

	// Get actural needed size for buffer.
	rst = pSampleGrabber->GetCurrentBuffer(&nBufferSize, NULL);

	// Create a buffer for storing image data.
	BYTE *pBuffer = (BYTE *)malloc(nBufferSize);

	// Get the image data with buffer.
	pSampleGrabber->GetCurrentBuffer(&nBufferSize, (long *)pBuffer);

	// Save buffer into BMP file with the information stored in VideoInfoHeader.
	WriteBitmap(fileName, &pVideoInfoHeader->bmiHeader, sizeof(BITMAPINFOHEADER), pBuffer, nBufferSize);

	// After saving, no matter the result the buffer should be released.
	free(pBuffer);

	return TRUE;
}

// Tell device to start capture and output data.
BOOL CameraFunctions::CMF_StartCapture()
{
	HRESULT hRst;
	IMediaControl *pMediaControl;
	hRst = pGraphBuilder->QueryInterface(IID_IMediaControl, (LPVOID *)&pMediaControl);
	if (hRst != S_OK)
	{
		return FALSE;
	}
	else
	{
		// Start capture
		pMediaControl->Run();
	}
	SafeRelease(pMediaControl);
	return TRUE;
}

// Tell device to stop capture and output data.
BOOL CameraFunctions::CMF_StopCapture()
{
	if (pGraphBuilder == NULL)
		return TRUE;

	HRESULT hRst;
	IMediaControl *pMediaControl;
	hRst = pGraphBuilder->QueryInterface(IID_IMediaControl, (LPVOID *)&pMediaControl);
	if (hRst != S_OK)
	{
		return FALSE;
	}
	else
	{
		// Stop capture
		pMediaControl->Stop();
	}
	SafeRelease(pMediaControl);
	return TRUE;
}

// Set output pin to stop for infinity period for pausing output.
void CameraFunctions::CMF_PauseAviCapture()
{
	// Pause AVI recording.
	REFERENCE_TIME pstart = NULL;
	REFERENCE_TIME pstop = 0;
	pCaptureGraphBuilder2->ControlStream(&PIN_CATEGORY_CAPTURE, &MEDIATYPE_Video, NULL, &pstart, &pstop, NULL, NULL);
}

// Set output pin from pausing to output.
void CameraFunctions::CMF_StartAviCapture()
{
	REFERENCE_TIME pstart = 0;
	REFERENCE_TIME pstop = MAXLONGLONG;
	pCaptureGraphBuilder2->ControlStream(&PIN_CATEGORY_CAPTURE, &MEDIATYPE_Video, NULL, &pstart, &pstop, NULL, NULL);
}

// Tear down rendered graph and release components. 
// This is necessary for any change of rendered graph by CaptureGraphBuilder2.
BOOL CameraFunctions::CMF_TeardownGraph()
{
	// Tear down current graph.
	if (pDeviceFilter)
		CMF_I_RemoveDownstream(pDeviceFilter);

	// Safely release DShow components.
	SafeRelease(pGraphBuilder);
	SafeRelease(pSampleGrabberFilter);
	SafeRelease(pSampleGrabber);
	SafeRelease(pMux);
	SafeRelease(pMsMpegEncoder);
	SafeRelease(pVideoWindow);
	SafeRelease(pCaptureGraphBuilder2);
	return true;
}

// Acquire current device output FPS.
float CameraFunctions::CMF_GetOutputFPS()
{
	HRESULT hRst;
	IAMStreamConfig *pVSC;
	hRst = pCaptureGraphBuilder2->FindInterface(&PIN_CATEGORY_CAPTURE, &MEDIATYPE_Video, pDeviceFilter, IID_IAMStreamConfig, (void **)&pVSC);
	if (hRst != S_OK)
		return -1;

	AM_MEDIA_TYPE *pmt;
	hRst = pVSC->GetFormat(&pmt);
	if (hRst != S_OK)
		return -1;

	if (pmt->formattype == FORMAT_VideoInfo)
	{
		VIDEOINFOHEADER *pvi = (VIDEOINFOHEADER *)pmt->pbFormat;
		float fFPS = (float)(10000000 / pvi->AvgTimePerFrame) ;
		CoTaskMemFree(pmt);
		SafeRelease(pVSC);
		return fFPS;
	}

	CoTaskMemFree(pmt);
	SafeRelease(pVSC);
	return -1;
}

// Set device output FPS.
BOOL CameraFunctions::CMF_SetOutputFPS(float tgtFrameRate)
{
	HRESULT hRst;
	IAMStreamConfig *pVSC;
	hRst = pCaptureGraphBuilder2->FindInterface(&PIN_CATEGORY_CAPTURE, &MEDIATYPE_Video, pDeviceFilter, IID_IAMStreamConfig, (void **)&pVSC);
	if (hRst != S_OK)
		return FALSE;

	AM_MEDIA_TYPE *pmt;
	hRst = pVSC->GetFormat(&pmt);
	if (hRst != S_OK)
		return FALSE;

	if (pmt->formattype == FORMAT_VideoInfo)
	{
		VIDEOINFOHEADER *pvi = (VIDEOINFOHEADER *)pmt->pbFormat;
		pvi->AvgTimePerFrame = (LONGLONG)(10000000 / tgtFrameRate);
		hRst = pVSC->SetFormat(pmt);
		if (hRst != S_OK)
		{
			CoTaskMemFree(pmt);
			SafeRelease(pVSC);
			return FALSE;
		}
	}

	CoTaskMemFree(pmt);
	SafeRelease(pVSC);
	return TRUE;
}

// Disconnect Camera.
// In fact this function release all the components and deinitialize COM components.
// Only call this function when everything is done.
void CameraFunctions::CMF_DisconnectCamera()
{
	SafeRelease(pGraphBuilder);
	SafeRelease(pSampleGrabberFilter);
	SafeRelease(pSampleGrabber);
	SafeRelease(pMux);
	SafeRelease(pMsMpegEncoder);
	SafeRelease(pVideoWindow);
	SafeRelease(pCaptureGraphBuilder2);
	// [180216] Add device filter release function for correctly release device after using.
	SafeRelease(pDeviceFilter);
	CoUninitialize();
}


// ========================
// (Inner function)
// Function of pin operation for tear down rendered graph.
// Generally just send device filter in then this function will tear down all connections of all filters connect to the device filter.
// This is necessary before trying to re-render a graph.
// Be aware that the last filter of a rendered graph should be the IGraphBuilder that added into GraphBuilderBuilder2.
void CameraFunctions::CMF_I_RemoveDownstream(IBaseFilter *pf)
{
	IPin *pP = 0, *pTo = 0;
	ULONG u;
	IEnumPins *pins = NULL;
	PIN_INFO pininfo;

	if (!pf)
		return;

	HRESULT hr = pf->EnumPins(&pins);
	pins->Reset();

	while (hr == NOERROR)
	{
		hr = pins->Next(1, &pP, &u);
		if (hr == S_OK && pP)
		{
			pP->ConnectedTo(&pTo);
			if (pTo)
			{
				hr = pTo->QueryPinInfo(&pininfo);
				if (hr == NOERROR)
				{
					if (pininfo.dir == PINDIR_INPUT)
					{
						CMF_I_RemoveDownstream(pininfo.pFilter);
						pGraphBuilder->Disconnect(pTo);
						pGraphBuilder->Disconnect(pP);
						pGraphBuilder->RemoveFilter(pininfo.pFilter);
					}
					pininfo.pFilter->Release();
				}
				pTo->Release();
			}
			pP->Release();
		}
	}
	if (pins)
		pins->Release();
}

// (Inner function)
// This function will try to find out if the "Microsoft MPEG-2 Video Encoder" base filter exist.
// Note that even if the filter exist, there may be other reason that the filter cannot be rendered.
// If not found, the IBaseFilter will be set to NULL.
bool CameraFunctions::CMF_I_FindMpegEncoderFilter(IBaseFilter **pFilter)
{
	bool bHit = FALSE;
	IBaseFilter * pMpegEncoder;
	HRESULT hRst;

	ICreateDevEnum *pDevEnum = NULL;
	CoCreateInstance(CLSID_SystemDeviceEnum, NULL, CLSCTX_INPROC_SERVER, IID_ICreateDevEnum, (void **)&pDevEnum);
	IEnumMoniker *pCompressorClassEnumMon = NULL;
	pDevEnum->CreateClassEnumerator(CLSID_MediaEncoderCategory, &pCompressorClassEnumMon, 0);

	pCompressorClassEnumMon->Reset();

	IMoniker *pCompressorMoniker = NULL;
	ULONG cFetched = 0;

	// We need to make sure of the compressor filter is set to Video encoder.
	// Note that Audio encoder and Video encoder have both the same filter name "Microsoft MPEG-2 Encoder" but we need to use the one for Video compression.
	// Following code shows how to check the detail of the pins of IBaseFilter to find the exact one for Video compression.

	// *If the filter is not avaliable (such as Win8/10, which have license issue), it will not accept binding and won't be check with returning false.

	while (pCompressorClassEnumMon->Next(1, &pCompressorMoniker, &cFetched) == S_OK)
	{
		hRst = pCompressorMoniker->BindToObject(0, 0, IID_IBaseFilter, (void **)&pMpegEncoder);
		if (hRst != S_OK)
			break;
		
		IEnumPins * pPinEnum = NULL;
		// List up all pins of current IBaseFilter to check if the filter do support Video input.
		hRst = pMpegEncoder->EnumPins(&pPinEnum);
		pPinEnum->Reset();
		IPin * pPinChker = NULL;
		
		while(pPinEnum->Next(1, &pPinChker, NULL) == S_OK)
		{
			IEnumMediaTypes * pMediaTypeEnum = NULL;
			// List up all media types can be accept by the pin to check if the pin support Video input
			hRst = pPinChker->EnumMediaTypes(&pMediaTypeEnum);
		
			pMediaTypeEnum->Reset();
			AM_MEDIA_TYPE * tmpMediaType = NULL;
			// Check AM_MEDIA_TYPE to see if its major type accept VIDEO input. Which shows the filter is MPEG video compress filter.
			while(pMediaTypeEnum->Next(1, &tmpMediaType, NULL) == S_OK)
			{
				if(tmpMediaType->majortype == MEDIATYPE_Video)
				//if(tmpMediaType->majortype == MEDIATYPE_Text)  //DBG Test
				{
					// Pin hit. We will need to use this IBaseFilter as Video compress filter.
					bHit = TRUE;
					
				}
				if(bHit)
				{
					*pFilter = pMpegEncoder;
					pMediaTypeEnum->Release();
					break;
				}
			}

			if(bHit)
			{
				pPinEnum->Release();
				pPinChker->Release();
				break;
			}
		}
		if(bHit)
		{
			break;
		}
	}

	pCompressorClassEnumMon->Release();
	pCompressorMoniker->Release();
	pDevEnum->Release();

	return bHit;

}

