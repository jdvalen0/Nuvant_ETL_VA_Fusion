#pragma once

#include <dshow.h>
#include <string.h>
#include <conio.h>

#include "resource.h"

// For BMP saving of snap
#include "BMPWriter.h"

// For SampleGrabber function (Original DShow header)
#include "qedit.h"

// DirectShow related library linking
#pragma comment(lib, "Strmbase.lib")
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "Msacm32.lib") 