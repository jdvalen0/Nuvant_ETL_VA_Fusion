/*
	CameraFunctions.h by OMRON SENTECH Support Team
	
	This header decleared the camera related funtions with using DirectShow.


 */
#pragma once

#include <dshow.h>
#include <string.h>
#include <conio.h>
#include <shlobj.h>

#include <wmcodecdsp.h>

#pragma comment(lib, "shell32.lib")

// Header for BMP saving of snap
#include "BMPWriter.h"
// Header for SampleGrabber functions (Ripped from old DShow header)
#include "qedit.h"

#include "StUVCViewer.h"

// Fixed camera name
#define	DEV_NAME	"STC-S133UVC"
// Macro for DirectShow components for safe release after using.
#define SafeRelease(x) { if (x) x->Release(); x = NULL; }

#define CMF_RTN	BYTE

class CameraFunctions
{
public:
	// == Object status flags structure
	struct _statFlag{
		BOOL	fIsPreviewing;			// If preview is on
		BOOL	fIsSnapOn;				// If Snap is enabled
		BOOL	fIsCaptureVideoOn;		// If Capture AVI is enabled
		BOOL	fIsOnCapture;			// If currently is capturing video to AVI
		BOOL	fIsConnected;			// If camera is connected

	} CMFstatFlagStorage;

	// == For DirectShow usage
	IGraphBuilder			*pGraphBuilder;
	ICaptureGraphBuilder2	*pCaptureGraphBuilder2;
	IBaseFilter				*pDeviceFilter;
	IBaseFilter				*pMux;
	IBaseFilter				*pMsMpegEncoder;
	// == For Snap usage
	IBaseFilter				*pSampleGrabberFilter;
	ISampleGrabber			*pSampleGrabber;
	VIDEOINFOHEADER			*pVideoInfoHeader;
	// == For Display usage
	IVideoWindow			*pVideoWindow;

	// == For saving default File path/name.
	wchar_t snapFileName[FILENAME_MAX];
	wchar_t VideoFileName[FILENAME_MAX];
	wchar_t VideoBasePath[FILENAME_MAX];

	// Counter for saving BMP.
	int BMP_SaveCount;

	// === Functions
	BOOL CMF_connectToCamera();
	BOOL CMF_openVideoFilterSetting(HWND parentWndHnd);
	BOOL CMF_openVideoPinSetting(HWND parentWndHnd);
	CMF_RTN CMF_RenderGraph();
	CMF_RTN CMF_RenderGraphWithInnerDisplay(HWND parentWnd);
	void CMF_SetDisplayVideoWndPos(long lX, long lY);
	BOOL CMF_Snap(wchar_t * fileName);
	BOOL CMF_StartCapture();
	BOOL CMF_StopCapture();
	void CMF_PauseAviCapture();
	void CMF_StartAviCapture();
	BOOL CMF_TeardownGraph();
	float CMF_GetOutputFPS();
	BOOL CMF_SetOutputFPS(float tgtFrameRate);
	void CMF_DisconnectCamera();

private:
	// == Inner function to tear down rendered graph
	void CMF_I_RemoveDownstream(IBaseFilter *pf);
	bool CMF_I_FindMpegEncoderFilter(IBaseFilter **pFilter);

};

// CameraFunctions class status return definition
#define CMF_OK												0x01
#define CMF_RENDER_OK_BUT_MPEG_ENCODER_NOT_AVAILABLE		0x02
#define CMF_RENDER_DEVICE_NOT_INITIALED						0x10
#define CMF_RENDER_SAMPLE_GRABBER_FAILED					0x11
#define CMF_RENDER_GET_MEDIA_TYPE_FAILED					0x12
#define CMF_RENDER_CANNOT_FOUND_INNER_DISPLAY_WINDOW		0x13
#define CMF_RENDER_CANNOT_ACQUIRE_MEDIA_FORMAT				0x14
#define CMF_FILE_NAME_NOT_SET								0x15
#define CMF_RENDER_NO_ENCODER_RENDER_FAILED					0x20
#define CMF_RENDER_ENCODER_FOUND_BUT_RENDER_FAILED			0x21
